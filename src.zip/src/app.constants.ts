export const MyBotName = 'botname';
